import React from 'react';
import CarInventoryApp from './CarInventoryApp';

function App() {
  return <CarInventoryApp />;
}

export default App;